To Run Spiral
rostopic pub /check_type std_ms/String "data: 'spiral'" 


To Run Linear
rostopic pub /check_type std_ms/String "data: 'linear'" 

